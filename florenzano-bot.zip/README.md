# 🤖 Florenzano WhatsApp Bot

Este é o bot oficial da Florenzano Boutique, criado em Node.js usando a biblioteca **whatsapp-web.js**.

---

## 🚀 Como rodar localmente

1. Instale o Node.js (versão 18 ou superior)
2. Abra o terminal dentro da pasta do projeto
3. Execute:
   ```bash
   npm install
   npm start
   ```
4. Escaneie o QR Code com o WhatsApp Web no seu celular
5. Pronto! O bot estará ativo 🎉

---

## ☁️ Como hospedar no Railway

1. Crie uma conta em [https://railway.app](https://railway.app)
2. Crie um novo projeto e conecte o repositório GitHub (ou envie os arquivos manualmente)
3. Vá em **Deploy Settings** e defina o comando de inicialização:
   ```bash
   npm start
   ```
4. Clique em **Deploy** e aguarde o QR Code aparecer nos logs.
5. Escaneie o QR Code e o bot ficará ativo 24h!

---

**Florenzano Boutique - Atendimento automatizado 💬**
