
// Florenzano Bot
const qrcode = require('qrcode-terminal');
const { Client, LocalAuth } = require('whatsapp-web.js');

const client = new Client({
    authStrategy: new LocalAuth()
});

const delay = ms => new Promise(res => setTimeout(res, ms));

client.on('qr', qr => {
    qrcode.generate(qr, { small: true });
});

client.on('ready', () => {
    console.log('✅ Tudo certo! WhatsApp conectado.');
});

client.initialize();

client.on('message', async msg => {
    const chat = await msg.getChat();
    const contact = await msg.getContact();
    const name = contact.pushname ? contact.pushname.split(" ")[0] : "";

    // MENU INICIAL
    if (msg.body.match(/^(menu|Menu|início|inicio|oi|olá|ola)$/i) && msg.from.endsWith('@c.us')) {
        await chat.sendStateTyping();
        await delay(2000);
        await client.sendMessage(msg.from, `👋 Olá ${name}! Sou a assistente virtual da Florenzano Boutique.
Como posso te ajudar hoje?

1️⃣ Ver catálogo da loja
2️⃣ Falar com um(a) vendedor(a)`);
        return;
    }

    // OPÇÃO 1 - CATÁLOGO
    if (msg.body === '1') {
        await chat.sendStateTyping();
        await delay(2000);
        await client.sendMessage(msg.from, '📖 Aqui está o link do nosso catálogo virtual:');
        await delay(1000);
        await client.sendMessage(msg.from, '🌐 https://loja.stoqui.com.br/florenzano-boutique');
        await delay(2000);
        await client.sendMessage(msg.from, 'Digite *menu* para voltar ao início.');
        return;
    }

    // OPÇÃO 2 - FALAR COM VENDEDOR
    if (msg.body === '2') {
        await chat.sendStateTyping();
        await delay(2000);
        await client.sendMessage(msg.from, '🏃‍♀️ Aguarde um instante enquanto chamo uma de nossas vendedoras para te atender 😊');
        await delay(2000);
        await client.sendMessage(msg.from, 'Digite *menu* para voltar ao início.');
        return;
    }

    // CASO NÃO RECONHEÇA
    if (msg.body && !msg.body.match(/^(1|2|menu|Menu)$/i)) {
        await chat.sendStateTyping();
        await delay(1000);
        await client.sendMessage(msg.from, '❓ Não entendi sua mensagem. Digite *menu* para ver as opções.');
    }
});
